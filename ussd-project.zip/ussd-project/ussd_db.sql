-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2024 at 10:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ussd_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `sender` varchar(15) DEFAULT NULL,
  `recipient` varchar(15) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` varchar(20) NOT NULL DEFAULT 'transfer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `sender`, `recipient`, `amount`, `date`, `type`) VALUES
(1, '+250728187215', '0788592728', 20.00, '2024-12-02 09:41:44', 'transfer'),
(2, '+250782187215', '0728187215', 200.00, '2024-12-02 09:54:26', 'transfer'),
(3, '+250728187215', NULL, 200.00, '2024-12-02 10:00:10', 'deposit'),
(4, '+250782187215', NULL, 2000.00, '2024-12-02 15:42:29', 'deposit'),
(5, '+250782187215', '0728187215', 1000.00, '2024-12-02 15:43:34', 'transfer'),
(6, '+250782187215', NULL, 2300.00, '2024-12-02 19:54:38', 'deposit'),
(7, '+250782187215', '0782187216', 120.00, '2024-12-02 19:55:10', 'transfer'),
(8, '+250782187215', NULL, 2500.00, '2024-12-02 19:57:16', 'deposit'),
(9, '+250782187215', '0728187215', 1200.00, '2024-12-02 19:57:56', 'transfer'),
(10, '+250788592729', NULL, 200.00, '2024-12-11 20:47:05', 'deposit'),
(11, '+250788592729', '+250782187215', 200.00, '2024-12-11 22:11:39', 'transfer'),
(12, '+250788592729', '+250782187215', 200.00, '2024-12-11 22:12:03', 'transfer'),
(13, '+250788592729', '+250782187215', 1000.00, '2024-12-11 22:12:47', 'transfer'),
(14, '+250782187215', '+250788592728', 3000.00, '2024-12-14 19:48:22', 'transfer'),
(15, '+250782187215', '+250728187215', 2100.00, '2024-12-14 20:40:17', 'transfer');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `names` varchar(50) NOT NULL,
  `PIN` int(4) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `phone_number`, `names`, `PIN`, `balance`) VALUES
(1, '0782187215', 'Jackson TUYISENGE', 2222, 6400.00),
(2, '0728187215', 'KAMANA Claude', 2222, 9300.00),
(3, '0788592728', 'TUYISENGE Jackson', 2222, 3000.00),
(4, '0788592729', 'UMULISA Gaston', 2222, 26000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
